# imports
# TODO: add your imports here

def get_my_model():
    model = ...
    # TODO: create your model instance here
    return model


def get_my_ds():
    my_ds = ...
    # TODO: add your dataset here
    # Hint: this may include multiple parts, you can return lists
    return my_ds


def train(model, ds):
    # TODO: add everything you need to train a model based on YOUR definition of the ds
    model = ...
    return model


def final_evaluate(model, ds):
    # TODO: evaluate your model based on YOUR definition of the ds
    # Hint: the final score should be a single number
    final_score = ...
    return final_score


def summary():
    # TODO: print all information that you think may be relevant
    print("Nothing added yet")